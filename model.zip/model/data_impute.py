#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 20 11:24:33 2021

@author: fanhang
"""

'''
import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('/Users/fanhang/Documents/chengdu80/data_train.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)
'''



#df_data_nnm = NuclearNormMinimization().fit_transform(df_data)


#df_datae_normalized = BiScaler().fit_transform(df_data)
#df_data_datasoftimpute = SoftImpute().fit_transform(df_data)
#df_data_datasoftimpute = np.concatenate((df_data_id,df_data_datasoftimpute),axis=1)



import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('./data_train_all.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)





df_knn_2 = pd.read_csv('./data_train_knn_all.csv')

lixibeishu = (df_knn_2['retained_profits']+df_knn_2['finance_expense']+df_knn_2['incometax_actual'])/df_knn_2['finance_expense']
df_knn_2['lixibeishu'] = lixibeishu

ROE = df_knn_2['retained_profits']/df_knn_2['TOTEQU']
df_knn_2['ROE'] = ROE

Gross_profit_margin = df_knn_2['gross_profit']/df_knn_2['revenue']
df_knn_2['Gross_profit_margin'] = Gross_profit_margin

Net_profit_margin = df_knn_2['retained_profits']/df_knn_2['revenue']
df_knn_2['Net_profit_margin '] = Net_profit_margin 

operating_cashflow = df_knn_2['revenue']-df_knn_2['sales_cost']-df_knn_2['sales_tax']-df_knn_2['finance_expense']
df_knn_2['operating_cashflow'] = operating_cashflow
#nianxian = df_knn_2['outdate']-df_knn_2['indate']

biandong = df_knn_2['TRANSAMAFT']- df_knn_2['TRANSAMPR']
df_knn_2['biandong '] = biandong 

shourubili = df_knn_2['ad_expenses']/df_knn_2['revenue']
df_knn_2['shourubili'] = shourubili

daiyu = (df_knn_2['payrol_expense'] + df_knn_2['welfare_expenses'] + df_knn_2['education_expenses'] +df_knn_2['union_funds'] )/df_knn_2['retained_profits']
df_knn_2['daiyu'] = daiyu

df_knn_2.to_csv('data_train_knn_all_append.csv')

###########################################################################################

import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('./data_test_less.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)

###########################################################################################

import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('./data_train_less.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)

###########################################################################################

import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('./data_test_more.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)

###########################################################################################

import fancyimpute
from fancyimpute import KNN, NuclearNormMinimization, SoftImpute, BiScaler
import pandas as pd
import numpy as np

df = pd.read_csv('./data_train_more.csv')


df_data = np.array(df)[:,2:]
df_data_id = np.array(df)[:,0:2]

m,n = np.shape(df_data)
for i in range(m):
    for j in range(n):
        if (df_data[i,j]=='!'):
            df_data[i,j] = 1
       
        if (type(df_data[i,j])==str):
            if ('￥' in df_data[i,j]):
                df_data[i,j] = float(df_data[i,j][1:])

df_data_knn = KNN(k=3).fit_transform(df_data)
df_data_knn = np.concatenate((df_data_id,df_data_knn),axis=1)


###########################################################################################

df_knn_2 = pd.read_csv('./data_train_more_knn.csv')

lixibeishu = (df_knn_2['retained_profits']+df_knn_2['finance_expense']+df_knn_2['incometax_actual'])/df_knn_2['finance_expense']
df_knn_2['lixibeishu'] = lixibeishu

ROE = df_knn_2['retained_profits']/df_knn_2['TOTEQU']
df_knn_2['ROE'] = ROE

Gross_profit_margin = df_knn_2['gross_profit']/df_knn_2['revenue']
df_knn_2['Gross_profit_margin'] = Gross_profit_margin

Net_profit_margin = df_knn_2['retained_profits']/df_knn_2['revenue']
df_knn_2['Net_profit_margin '] = Net_profit_margin 

operating_cashflow = df_knn_2['revenue']-df_knn_2['sales_cost']-df_knn_2['sales_tax']-df_knn_2['finance_expense']
df_knn_2['operating_cashflow'] = operating_cashflow
#nianxian = df_knn_2['outdate']-df_knn_2['indate']

biandong = df_knn_2['TRANSAMAFT']- df_knn_2['TRANSAMPR']
df_knn_2['biandong '] = biandong 

shourubili = df_knn_2['ad_expenses']/df_knn_2['revenue']
df_knn_2['shourubili'] = shourubili

daiyu = (df_knn_2['payrol_expense'] + df_knn_2['welfare_expenses'] + df_knn_2['education_expenses'] +df_knn_2['union_funds'] )/df_knn_2['retained_profits']
df_knn_2['daiyu'] = daiyu

df_knn_2.to_csv('./data_train_more_knn_append.csv')

###########################################################################################


df_knn_2 = pd.read_csv('./data_test_more_knn.csv')

lixibeishu = (df_knn_2['retained_profits']+df_knn_2['finance_expense']+df_knn_2['incometax_actual'])/df_knn_2['finance_expense']
df_knn_2['lixibeishu'] = lixibeishu

ROE = df_knn_2['retained_profits']/df_knn_2['TOTEQU']
df_knn_2['ROE'] = ROE

Gross_profit_margin = df_knn_2['gross_profit']/df_knn_2['revenue']
df_knn_2['Gross_profit_margin'] = Gross_profit_margin

Net_profit_margin = df_knn_2['retained_profits']/df_knn_2['revenue']
df_knn_2['Net_profit_margin '] = Net_profit_margin 

operating_cashflow = df_knn_2['revenue']-df_knn_2['sales_cost']-df_knn_2['sales_tax']-df_knn_2['finance_expense']
df_knn_2['operating_cashflow'] = operating_cashflow
#nianxian = df_knn_2['outdate']-df_knn_2['indate']

biandong = df_knn_2['TRANSAMAFT']- df_knn_2['TRANSAMPR']
df_knn_2['biandong '] = biandong 

shourubili = df_knn_2['ad_expenses']/df_knn_2['revenue']
df_knn_2['shourubili'] = shourubili

daiyu = (df_knn_2['payrol_expense'] + df_knn_2['welfare_expenses'] + df_knn_2['education_expenses'] +df_knn_2['union_funds'] )/df_knn_2['retained_profits']
df_knn_2['daiyu'] = daiyu

df_knn_2.to_csv('./data_test_more_knn_append.csv')
