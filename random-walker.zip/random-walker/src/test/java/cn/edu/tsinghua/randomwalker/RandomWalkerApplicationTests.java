package cn.edu.tsinghua.randomwalker;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomWalkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
