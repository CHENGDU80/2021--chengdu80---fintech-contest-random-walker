package cn.edu.tsinghua.randomwalker.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * @ClassName DetailController
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/19 下午8:00
 * @Version 1.0
 **/
@Controller
public class DetailController {
    @RequestMapping(value = "/corpratedetail")
    @ResponseBody
    public ModelAndView corpratedetail(HttpServletRequest request,@RequestParam(value="entid") String entId){
        String username =request.getParameter("username");
        if (username!=null){
            return new ModelAndView("corprate-detail")
                    .addObject("username",username)
                    .addObject("entId",entId);
        }else{
            return new ModelAndView("auth-login");
        }

    }
}
