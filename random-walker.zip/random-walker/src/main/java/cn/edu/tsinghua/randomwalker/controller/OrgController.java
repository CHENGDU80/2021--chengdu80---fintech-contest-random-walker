package cn.edu.tsinghua.randomwalker.controller;

import cn.edu.tsinghua.randomwalker.entity.OrgEnterprise;
import cn.edu.tsinghua.randomwalker.entity.OrgRepairItem;
import cn.edu.tsinghua.randomwalker.entity.OrgUrgent;
import cn.edu.tsinghua.randomwalker.service.OrgSerivce;
import net.sf.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName OrgController
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:59
 * @Version 1.0
 **/
@Controller
public class OrgController {

    private static final Logger logger = LoggerFactory.getLogger(OrgController.class);


    @Autowired
    OrgSerivce orgSerivce;

    @RequestMapping("/getOrgUrgentList")
    public String getOrgUrgentList(Model model){
        List<OrgUrgent> orgUrgentList = orgSerivce.getOrgUrgentList();
        model.addAttribute("orgUrgentList", orgUrgentList);
        return "index::org_urgent";
    }


    @RequestMapping("/getOrgRepairItemList")
    public String getOrgRepairItemList(Model model){
        List<OrgRepairItem> orgRepairItemList = orgSerivce.getOrgRepairItemList();
        model.addAttribute("orgRepairItemList", orgRepairItemList);
        return "index::org_repair_item";
    }

    @RequestMapping("/getOrgRiskDashbord")
    @ResponseBody
    public String getOrgRiskDashbord(@RequestParam(value="type") int type){
        //type=0 行业
        //type=1 地区
        List<OrgEnterprise>  OrgEnterpriseList = new ArrayList<>();
        List<Float> riskProList = new ArrayList<>();
        Map<String,List> map = new HashMap<>();

        if(type==0){
            OrgEnterpriseList = orgSerivce.selectByIndusty();
            List<Integer> industyList =new ArrayList<>();
            OrgEnterpriseList.forEach(orgEnterprise->{
                industyList.add(orgEnterprise.getIndusty());
                riskProList.add(orgEnterprise.getRiskpro());
            });
            map.put("industy",industyList);
        }else{
            OrgEnterpriseList = orgSerivce.selectByRagion();
            List<Integer> ragionList =new ArrayList<>();
            OrgEnterpriseList.forEach(orgEnterprise->{
                ragionList.add(orgEnterprise.getRagion());
                riskProList.add(orgEnterprise.getRiskpro());
            });
            map.put("ragion",ragionList);
        }

        map.put("riskpro",riskProList);
        JSONArray json  =  JSONArray.fromObject(map);
        logger.info("OrgEnterpriseList:{}",json);
        return  json.toString();
    }

}
