package cn.edu.tsinghua.randomwalker.service;

import cn.edu.tsinghua.randomwalker.entity.OrgEnterprise;
import cn.edu.tsinghua.randomwalker.entity.OrgRepairItem;
import cn.edu.tsinghua.randomwalker.entity.OrgUrgent;

import java.util.List;

/**
 * @ClassName OrgSerivce
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:46
 * @Version 1.0
 **/
public interface OrgSerivce {
    List<OrgUrgent> getOrgUrgentList();
    List<OrgRepairItem> getOrgRepairItemList();

    /**
     * 分行业查看风险概率
     */
    List<OrgEnterprise> selectByIndusty();

    /**
     * 分区域查看风险概率
     */
    List<OrgEnterprise> selectByRagion();
}
