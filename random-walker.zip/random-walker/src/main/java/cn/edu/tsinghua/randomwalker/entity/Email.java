package cn.edu.tsinghua.randomwalker.entity;

import lombok.Data;

import java.util.Date;

/**
 * @ClassName Email
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/19 下午7:50
 * @Version 1.0
 **/
@Data
public class Email {
    private int id;
    private String title;
    private String content;
    private Date sdate;
}
