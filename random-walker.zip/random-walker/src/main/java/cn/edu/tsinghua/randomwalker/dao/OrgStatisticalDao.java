package cn.edu.tsinghua.randomwalker.dao;

/**
 * @ClassName OrgStatisticalDao
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:30
 * @Version 1.0
 **/
public interface OrgStatisticalDao {
}
