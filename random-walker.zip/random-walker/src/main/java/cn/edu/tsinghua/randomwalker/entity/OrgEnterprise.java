package cn.edu.tsinghua.randomwalker.entity;

import lombok.Data;

/**
 * @ClassName OrgEnterprise
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 下午12:42
 * @Version 1.0
 **/
@Data
public class OrgEnterprise {
    private int id;
    private String entid;
    private float riskpro;
    private float riskproAvg;
    private int industy;
    private int ragion;
}
