package cn.edu.tsinghua.randomwalker.dao;

import cn.edu.tsinghua.randomwalker.entity.OrgRepairItem;
import cn.edu.tsinghua.randomwalker.entity.OrgUrgent;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName OrgRepairItemDao
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午10:54
 * @Version 1.0
 **/
@Repository
public interface OrgRepairItemDao {
    /**
     * 通过用户username查询用户
     * @param top 查看前5行
     */
    List<OrgRepairItem> getOrgRepairItemTop5(int top);
}
