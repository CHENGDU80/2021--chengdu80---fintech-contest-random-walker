package cn.edu.tsinghua.randomwalker.entity;

import lombok.Data;

import java.util.Date;

/**
 * @ClassName OrgUrgent
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:32
 * @Version 1.0
 **/
@Data
public class OrgUrgent {
    private int id;
    private String title;
    private String desc;
    private String entid;
    private Date createdate;
}
