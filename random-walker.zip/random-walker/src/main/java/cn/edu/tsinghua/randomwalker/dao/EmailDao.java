package cn.edu.tsinghua.randomwalker.dao;

import org.springframework.stereotype.Repository;

/**
 * @ClassName EmailDao
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/19 下午7:50
 * @Version 1.0
 **/
@Repository
public interface EmailDao {
}
