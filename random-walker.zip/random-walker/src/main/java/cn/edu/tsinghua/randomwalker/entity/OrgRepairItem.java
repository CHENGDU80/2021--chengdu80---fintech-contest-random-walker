package cn.edu.tsinghua.randomwalker.entity;

import lombok.Data;

import java.util.Date;

/**
 * @ClassName OrgRepairItem
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午10:44
 * @Version 1.0
 **/
@Data
public class OrgRepairItem {
    private int id;
    private String title;
    private String content;
    private String stakeholder;
    private int costtime;
    private String entid;
}
