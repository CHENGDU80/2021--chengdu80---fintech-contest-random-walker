package cn.edu.tsinghua.randomwalker.dao;

import cn.edu.tsinghua.randomwalker.entity.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName UserDao
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午6:18
 * @Version 1.0
 **/
@Repository
public interface UserDao {

    /**
     * 登陆验证
     * @param username
     * @param password
     * @return
     */
    /**
     * 通过用户username查询用户
     * @param username
     */
    List<User> selectUserByUsername(@Param("username")String username);

    User selectUser(@Param("username") String username, @Param("password") String password);
    /**
     * 注册用户
     * @param email
     * @param username
     * @param password
     */
    void addUser(@Param("email") String email, @Param("username") String username,@Param("password") String password);

}
