package cn.edu.tsinghua.randomwalker.dao;

import cn.edu.tsinghua.randomwalker.entity.OrgEnterprise;
import cn.edu.tsinghua.randomwalker.entity.OrgRepairItem;

import java.util.List;

/**
 * @ClassName OrgEnterpriseDao
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 下午12:43
 * @Version 1.0
 **/
public interface OrgEnterpriseDao {

    /**
     * 分行业查看风险概率
     */
    List<OrgEnterprise> selectByIndusty();

    /**
     * 分区域查看风险概率
     */
    List<OrgEnterprise> selectByRagion();
}
