package cn.edu.tsinghua.randomwalker.service;

import cn.edu.tsinghua.randomwalker.entity.User;

import java.util.List;

/**
 * @ClassName UserService
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午6:21
 * @Version 1.0
 **/
public interface UserService {
    /**
     * 通过用户id查询用户
     * @param username
     */
    List<User> selectUserByUsername(String username);

    /**
     * 登陆验证
     * @param username
     * @param password
     * @return
     */
    User selectUser(String username, String password);

    /**
     * 注册用户
     * @param email
     * @param username
     * @param password
     */
    void addUser(String email,String username,String password);
}
