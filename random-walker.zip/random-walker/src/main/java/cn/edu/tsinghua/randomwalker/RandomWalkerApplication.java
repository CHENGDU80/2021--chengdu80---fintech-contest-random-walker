package cn.edu.tsinghua.randomwalker;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("cn.edu.tsinghua.randomwalker.dao")
public class RandomWalkerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RandomWalkerApplication.class, args);
    }

}
