package cn.edu.tsinghua.randomwalker.controller;

import cn.edu.tsinghua.randomwalker.entity.User;
import cn.edu.tsinghua.randomwalker.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @ClassName IndexController
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午3:17
 * @Version 1.0
 **/
@Controller
public class IndexController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "/index")
    @ResponseBody
    public ModelAndView index(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            if(userType==0){
                return new ModelAndView("index")
                        .addObject("username",username)
                        .addObject("userType",userType)
                        .addObject("entId",entId);
            }else if(userType==1){
                return new ModelAndView("corprate-detail")
                        .addObject("username",username)
                        .addObject("userType",userType)
                        .addObject("entId",entId);
            }else{
                return new ModelAndView("person-detail")
                        .addObject("username",username)
                        .addObject("userType",userType)
                        .addObject("entId",entId);
            }




        }else{
            return new ModelAndView("auth-login");
        }

    }
    @RequestMapping(value = "/aboutus")
    @ResponseBody
    public ModelAndView aboutus(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("aboutus")
                    .addObject("username",username)
                    .addObject("userType",userType)
                    .addObject("entId",entId);

        }else{
            return new ModelAndView("auth-login");
        }

    }

    @RequestMapping(value = "/emailInbox")
    @ResponseBody
    public ModelAndView emailInbox(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("email-inbox")
                    .addObject("username",username)
                    .addObject("userType",userType)
                    .addObject("entId",entId);


        }else{
            return new ModelAndView("auth-login");
        }

    }

    @RequestMapping(value = "/chat")
    @ResponseBody
    public ModelAndView chat(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("chat")
                    .addObject("username",username)
                    .addObject("userType",userType)
                    .addObject("entId",entId);
        }else{
            return new ModelAndView("auth-login");
        }

    }
    @RequestMapping(value = "/emailRead")
    @ResponseBody
    public ModelAndView emailRead(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("email-read")
                    .addObject("username",username)
                    .addObject("userType",userType)
                    .addObject("entId",entId);

        }else{
            return new ModelAndView("auth-login");
        }

    }

    @RequestMapping(value = "/emailCompose")
    @ResponseBody
    public ModelAndView emailCompose(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("email-compose").addObject("username",username);
        }else{
            return new ModelAndView("auth-login");
        }

    }

    @RequestMapping(value = "/toCalendar")
    @ResponseBody
    public ModelAndView toCalendar(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("calendar").addObject("username",username);
        }else{
            return new ModelAndView("auth-login");
        }

    }


    @RequestMapping(value = "/personview")
    @ResponseBody
    public ModelAndView toPersonView(HttpServletRequest request){
        String username =request.getParameter("username");
        List<User> userList= userService.selectUserByUsername(username);
        int userType = 0;
        String entId = "";
        if(userList!=null && userList.size()==1){
            userType= userList.get(0).getUserType();
            entId =  userList.get(0).getEntId();
        }
        if (username!=null){
            return new ModelAndView("person-detail").addObject("username",username);
        }else{
            return new ModelAndView("auth-login");
        }

    }

}
