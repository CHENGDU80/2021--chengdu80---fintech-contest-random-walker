package cn.edu.tsinghua.randomwalker.service;

import cn.edu.tsinghua.randomwalker.entity.Email;

import java.util.List;

/**
 * @ClassName EmailService
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/19 下午7:53
 * @Version 1.0
 **/
public interface EmailService {
    List<Email> selectTop5();
}
