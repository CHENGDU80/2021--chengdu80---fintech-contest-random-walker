package cn.edu.tsinghua.randomwalker.entity;

import lombok.Data;

/**
 * @ClassName OrgStatistical
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:31
 * @Version 1.0
 **/
@Data
public class OrgStatistical {
    private int userId;
//    private
}
