package cn.edu.tsinghua.randomwalker.dao;

import cn.edu.tsinghua.randomwalker.entity.OrgUrgent;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName OrgUrgent
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:40
 * @Version 1.0
 **/
@Repository
public interface OrgUrgentDao {
    /**
     * 通过用户username查询用户
     * @param top 查看前5行
     */
    List<OrgUrgent> getOrgUrgentTop5(int top);
}
