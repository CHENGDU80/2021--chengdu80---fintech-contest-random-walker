package cn.edu.tsinghua.randomwalker.service.impl;

import cn.edu.tsinghua.randomwalker.dao.OrgEnterpriseDao;
import cn.edu.tsinghua.randomwalker.dao.OrgRepairItemDao;
import cn.edu.tsinghua.randomwalker.dao.OrgUrgentDao;
import cn.edu.tsinghua.randomwalker.entity.OrgEnterprise;
import cn.edu.tsinghua.randomwalker.entity.OrgRepairItem;
import cn.edu.tsinghua.randomwalker.entity.OrgUrgent;
import cn.edu.tsinghua.randomwalker.service.OrgSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName OrgServiceImpl
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/20 上午8:46
 * @Version 1.0
 **/
@Service
public class OrgServiceImpl implements OrgSerivce {
    @Autowired
    OrgUrgentDao orgUrgentDao;
    @Autowired
    OrgRepairItemDao orgRepairItemDao;
    @Autowired
    OrgEnterpriseDao orgEnterpriseDao;


    @Override
    public List<OrgUrgent> getOrgUrgentList() {
        return orgUrgentDao.getOrgUrgentTop5(5);

    }

    @Override
    public List<OrgRepairItem> getOrgRepairItemList() {
        return orgRepairItemDao.getOrgRepairItemTop5(5);
    }

    @Override
    public List<OrgEnterprise> selectByIndusty() {
        return orgEnterpriseDao.selectByIndusty();
    }

    @Override
    public List<OrgEnterprise> selectByRagion() {
        return orgEnterpriseDao.selectByIndusty();
    }


}
