package cn.edu.tsinghua.randomwalker.entity;


import lombok.Data;

/**
 * @ClassName User
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午5:28
 * @Version 1.0
 **/
@Data
public class User {
    private int userId;
    private String username;
    private String password;
    private int userType;
    private String email;
    private String entId;

}
