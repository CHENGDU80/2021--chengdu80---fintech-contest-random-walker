package cn.edu.tsinghua.randomwalker.controller;

import cn.edu.tsinghua.randomwalker.entity.User;
import cn.edu.tsinghua.randomwalker.service.UserService;
import cn.edu.tsinghua.randomwalker.utils.MD5Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

/**
 * @ClassName UserController
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午1:13
 * @Version 1.0
 **/
@Controller
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;

    /**
     * 系统首页
     * @return
     */
    @RequestMapping("/")
    public String toIndex(){
        return "auth-login";
    }

    @RequestMapping(value = "/logintoindex")
    @ResponseBody
    public String loginIndex(@RequestParam(value="username") String username, @RequestParam(value="password") String password){
//        User user=new User();
//        user.setUsername(username);
//        user.setPassword(password);
//       logger.info("login to index" );
//        logger.info("username:{},password:{}",username,password);
        List<User> userList= userService.selectUserByUsername(username);
        logger.info("userList.size:{} ",userList.size() );
        if (userList==null ){
            return   "{\"errorCode\":\"11\",\"errorMessage\":\"该用户不存在！\"}";
        }
        if (userList.size()!=1){
            return   "{\"errorCode\":\"22\",\"errorMessage\":\"登录异常，请联系管理员！\"}";
        }
        logger.info("username:{}, password:{}",username,MD5Utils.getMD5("111"));
        User user = userService.selectUser(username, password);
//        int userType = user.getUserType();

        if (user!=null){
            return   "{\"errorCode\":\"00\",\"errorMessage\":\"登陆成功！\"}";
        }else{
            return   "{\"errorCode\":\"33\",\"errorMessage\":\"用户名或密码错误！\"}";
        }
    }

//    @RequestMapping(value = "/login", method = RequestMethod.POST)
//    public void login(String username,String password){
//        LOG.debug("username: {},password:{}",username,password );
//    }

    /**
     * 跳转到登录界面
     * @return
     */
    @RequestMapping("/regist")
    public String regist(){
        return "auth-register";
    }
    /**
     * 注册
     * @return
     */
    @RequestMapping("/toRegist")
    @ResponseBody
    public String toregist(@RequestParam(value="useremail") String useremail,
                           @RequestParam(value="username") String username,
                           @RequestParam(value="password") String password){
        userService.addUser(useremail,username,password);
        return   "{\"errorCode\":\"00\",\"errorMessage\":\"注册成功！\"}";
    }
    /**
     * 找回密码
     * @return
     */
    @RequestMapping("/forgotPasswd")
    public String forgotPasswd(){
        return   "auth-recoverpw";
    }

}
