package cn.edu.tsinghua.randomwalker.service.impl;

import cn.edu.tsinghua.randomwalker.dao.UserDao;
import cn.edu.tsinghua.randomwalker.entity.User;
import cn.edu.tsinghua.randomwalker.service.UserService;
import cn.edu.tsinghua.randomwalker.utils.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName UserServiceImpl
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/18 下午6:22
 * @Version 1.0
 **/
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserDao userDao;

    @Override
    public User selectUser(String username, String password) {
        password= MD5Utils.getMD5(password);
        return userDao.selectUser(username,password);
    }

    @Override
    public List<User> selectUserByUsername(String username) {
        return userDao.selectUserByUsername(username);
    }

    @Override
    public void addUser(String email, String username, String password) {
        password=MD5Utils.getMD5(password);
        userDao.addUser(email,username,password);
    }

}
