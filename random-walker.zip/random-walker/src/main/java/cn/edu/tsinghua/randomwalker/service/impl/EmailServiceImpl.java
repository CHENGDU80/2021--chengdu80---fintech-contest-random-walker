package cn.edu.tsinghua.randomwalker.service.impl;

import cn.edu.tsinghua.randomwalker.entity.Email;
import cn.edu.tsinghua.randomwalker.service.EmailService;

import java.util.List;

/**
 * @ClassName EmailServiceImpl
 * @Description TODO
 * @Author cuiyan
 * @Date 2021/7/19 下午7:53
 * @Version 1.0
 **/
public class EmailServiceImpl implements EmailService {
    @Override
    public List<Email> selectTop5() {
        return null;
    }
}
