1. panda risk control system is designed for investor, manager and the regulator 

2. in order to provide the judge a general view of the panda, the level of your authority is the highest

3. we hope you can use panda anywhere you need. so we adjust panda to make it can function well in all kinds of devices


4. we advice you run panda in PC at the first time so that we can ensure good experience for you

5. Login username : test
   Login password: 111
 And you also an registe a new  account.